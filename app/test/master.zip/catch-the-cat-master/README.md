#原作者github地址：https://github.com/ganlvtech/phaser-catch-the-cat

#此处为成品代码。